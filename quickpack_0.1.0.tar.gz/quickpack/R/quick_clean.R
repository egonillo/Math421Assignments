quick_clean <- function(df, p)
{
  if(p == 1)
  {
    fixcol = function(y)
    {if(is.numeric(y) == TRUE)
    {y[is.na(y)] = mean(y, na.rm = TRUE)}
      else
      {
        levels = unique(y)
        y[is.na(y)] = levels[which.max(tabulate(match(y, levels)))]
      }
      return(y)
    }
    df = lapply(df, fixcol)
    return(data.frame(df))
  }
  else if (p==0)
  {
    na.omit(df)
  }
  else
  {print("Argument 2 needs to be 0 or 1")}
}

