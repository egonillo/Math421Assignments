quick_visual <- function(df, p)
{
  library(ggplot2)
  if(p == 1)
  {  for(i in 1:ncol(df))
  {for(j in 1:ncol(df))
  {if(is.numeric(df[,j]) == FALSE & (is.numeric(df[,i])==FALSE) & i != j & (nlevels(df[,i]) < 5) & (nlevels(df[,j]) < 5))
  {print(ggplot(df) + geom_bar(mapping = aes(x=df[,i], fill = df[,j]),na.rm = TRUE)+labs(x = names(df)[i], fill = names(df)[j]))}
  }
  }}
  else if(p == 2)
  {for(i in 1:ncol(df))
  {for (j in 1:ncol(df))
  {if(is.numeric(df[,i]) == TRUE & is.numeric(df[,j]) == FALSE & (nlevels(df[,j]) < 5))
  {print(ggplot(df) + geom_density(mapping = aes(x=df[,i],  color = df[,j]))+labs(x = names(df)[i],color = names(df[j])))}
  }
  }
  }
  else if(p == 3)
  {  for(i in 1:ncol(df))
  {for(j in 1:ncol(df))
  {
    if (is.numeric(df[,i]) == TRUE & is.numeric(df[,j]) == TRUE & i !=j)
    {
      print(ggplot(df) + geom_point(mapping = aes(x=df[,i], y = df[,j] ),na.rm = TRUE)+labs(x = names(df)[i], y = names(df)[j]))}
  }}
  }
  else
  {print("Argument 2 needs to be 1, 2, or 3")}
}
