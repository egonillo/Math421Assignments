quick_model <- function(df, trainp, pos)

{
  library(caret)
  splitIndex <- createDataPartition(df$target, p = trainp , list = FALSE, times = 1)
  train <- df[ splitIndex,]
  test <- df[-splitIndex,]


  library(ranger)
  model = ranger(target ~., data = train)
  pred  = predict(model, data = test)$predictions
  cm=confusionMatrix(pred, test$target, positive= pos)
  cm$overall['Accuracy']
}
